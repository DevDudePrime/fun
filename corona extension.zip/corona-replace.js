let bodyElements = [...document.body.getElementsByTagName('*')];

	let imgs = document.getElementsByTagName('img');

	for(var imgElt of imgs) {
		//console.log(imgElt.alt);
		if(imgElt.alt.includes('coronavirus') || imgElt.alt.includes('Coronavirus')){
			imgElt.src = "https://i.imgur.com/z4OvJns.jpg";
		}
	}
	
	function crispr(){
		bodyElements.forEach(element =>{
			element.childNodes.forEach(child =>{
				if(child.nodeType === 3){
					cas9(child);
				}
			});
		});
	}
	
	function cas9 (node) {
		let content = node.nodeValue;

		content = content.replace(/COVID/g,"CORONA");
		content = content.replace(/coronaviruses/g,"Corona beers");
		content = content.replace(/Coronaviruses/g,"Corona beers");
		content = content.replace(/coronavirus/g,"Corona beer");
		content = content.replace(/Coronavirus/g,"Corona beer");
		content = content.replace(/Coronavirus/g,"Corona beer");
		
		if(content.includes('Corona beer') || content.includes('coronavirus') ) {
			console.log(content);
			content = content.replace(/virus/g,"beer");
		}
		node.nodeValue = content;
	}
	window.onload = crispr();